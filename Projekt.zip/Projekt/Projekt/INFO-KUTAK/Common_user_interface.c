#include "Korisnik_bez_naloga.h"
#include "Grad.h"
#include <conio.h>

           int main()
             {
                  LISTA events;
                  Read_File(&events);

                  CATEGORY categories=Read_Catg_File();
                  char regime;
                  int flag=0;                               //odabir funkcije sistema

                  do
                  {
                       Print_Front_Page("Naslovna.txt");
                       Print_Menu();

                       scanf("\n%c",&regime);

                       if(regime == '1')
                        Print_Events_By_Time(&events,0);

                       else if(regime == '2')
                        Print_Events_By_Time(&events,-1);

                       else if(regime == '3')
                        Print_Events_By_Time(&events,1);

                       else if(regime == '4')
                        Quiz();

                       else if(regime == '5')
                       {
                            Add_Comment_To_Event(&events);
                            ++flag;
                       }


                       else if(regime == '6')
                        Print_City_User();

                       else if(regime == '7')
                        Print_Events_By_Category(&events,categories);

                        else if(regime == '8')
                            Print_All_Events(&events);

                        else if(regime == '9')
                             Print_Front_Page("Autori.txt");

                       else if(regime != '#')
                        printf("Nepoznata opcija!\n");

                       getch();                //enter
                       system("cls");          //osvjezavanje konzole

                  }while(regime != '#');

                  if(flag > 0)
                  Write_File(&events);

                  Delete_List(&events);
                  Delete_Catg_Arr(&categories);

                  printf("Hvala vam za vasu posjetu i dodjite nam opet!");
                  getch();

                  return 0;

             }

